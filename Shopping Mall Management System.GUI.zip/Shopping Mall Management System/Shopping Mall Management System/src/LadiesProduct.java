public class LadiesProduct extends Product
{
    public LadiesProduct(String name, String description, double price, int id) {
        super(name, description, price, id);
    }

    public LadiesProduct() {
        super();
    }
}
